package codigo_fuente.conjuntos;

import java.util.HashSet;
import java.util.Set;

// Este código solo es de ayuda para el ejercicio. No es necesario utilizarlo.
public class Orden {
    public static void main(String[] args) {
        Set<String> conjunto = new Set<>();

        conjunto.add("dos"); 
        conjunto.add("uno");
        conjunto.add("cuatro");
        conjunto.add("tres");
        conjunto.add("cinco");   
    }
}
